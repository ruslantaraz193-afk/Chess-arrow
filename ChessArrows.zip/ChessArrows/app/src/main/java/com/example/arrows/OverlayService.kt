package com.example.arrows

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var canvas: ArrowView
    private lateinit var canvasLp: LP
    private lateinit var bar: LinearLayout
    private lateinit var btnDraw: TextView
    private lateinit var btnCal: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("arrows", "Arrows", NotificationManager.IMPORTANCE_MIN))
        startForeground(
            1,
            Notification.Builder(this, "arrows")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("Chess Arrows").build()
        )
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("p", MODE_PRIVATE)

        canvas = ArrowView(this)
        if (prefs.contains("l")) {
            canvas.board = RectF(
                prefs.getFloat("l", 0f), prefs.getFloat("t", 0f),
                prefs.getFloat("r", 0f), prefs.getFloat("b", 0f)
            )
        }
        canvas.onBoardSet = { r ->
            prefs.edit().putFloat("l", r.left).putFloat("t", r.top)
                .putFloat("r", r.right).putFloat("b", r.bottom).apply()
            setMode(1)
        }
        canvasLp = LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        canvasLp.gravity = Gravity.TOP or Gravity.START
        // Android 12+ blocks touches through overlays with alpha > 0.8
        canvasLp.alpha = 0.8f
        if (Build.VERSION.SDK_INT >= 28) {
            canvasLp.layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        wm.addView(canvas, canvasLp)

        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(0xCC333333.toInt()); setPadding(24, 20, 24, 20)
            setOnClickListener { onClick() }
        }
        bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val handle = btn("≡") {}
        btnDraw = btn("✏") { setMode(if (canvas.mode == 1) 0 else 1) }
        btnCal = btn("⌗") { setMode(if (canvas.mode == 2) 0 else 2) }
        val clr = btn("✕") { canvas.clear() }
        val off = btn("⏻") { stopSelf() }
        for (v in listOf(handle, btnDraw, btnCal, clr, off)) {
            bar.addView(v, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 6 })
        }

        val barLp = LP(
            LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        )
        barLp.gravity = Gravity.TOP or Gravity.START
        barLp.x = 0; barLp.y = 400
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = barLp.x; oy = barLp.y }
                MotionEvent.ACTION_MOVE -> {
                    barLp.x = ox + (e.rawX - dx).toInt()
                    barLp.y = oy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        wm.addView(bar, barLp)
    }

    private fun setMode(m: Int) {
        canvas.mode = m
        canvasLp.flags = if (m == 0) canvasLp.flags or LP.FLAG_NOT_TOUCHABLE
        else canvasLp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(canvas, canvasLp)
        btnDraw.setBackgroundColor(if (m == 1) 0xCCE65100.toInt() else 0xCC333333.toInt())
        btnCal.setBackgroundColor(if (m == 2) 0xCC1B5E20.toInt() else 0xCC333333.toInt())
        canvas.invalidate()
        if (m == 2) Toast.makeText(this, "Обведи рамкой всю доску: из угла в угол", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        try { wm.removeView(canvas); wm.removeView(bar) } catch (_: Exception) {}
        super.onDestroy()
    }
}
