package com.example.arrows

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class ArrowView(c: Context) : View(c) {
    var mode = 0 // 0 = off (touches pass through), 1 = draw, 2 = calibrate board
    var board: RectF? = null
    var onBoardSet: ((RectF) -> Unit)? = null

    private class A(val x1: Float, val y1: Float, val x2: Float, val y2: Float)

    private val items = mutableListOf<A>()
    private var cur: A? = null
    private var tmp: RectF? = null
    private var sx = 0f
    private var sy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF9800.toInt() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF9800.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E676.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }

    fun clear() { items.clear(); cur = null; invalidate() }

    private fun sq(): Float = (board?.width() ?: 800f) / 8f

    // snap a point to the centre of its square (if the board is calibrated)
    private fun snap(x: Float, y: Float): PointF {
        val b = board ?: return PointF(x, y)
        val w = b.width() / 8f
        val h = b.height() / 8f
        val cx = floor(((x - b.left) / w).coerceIn(0f, 7.99f))
        val cy = floor(((y - b.top) / h).coerceIn(0f, 7.99f))
        return PointF(b.left + (cx + 0.5f) * w, b.top + (cy + 0.5f) * h)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y
                if (mode == 1) { val p = snap(sx, sy); cur = A(p.x, p.y, p.x, p.y) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1) {
                    val p = snap(e.x, e.y)
                    cur?.let { cur = A(it.x1, it.y1, p.x, p.y) }
                } else {
                    tmp = RectF(min(sx, e.x), min(sy, e.y), max(sx, e.x), max(sy, e.y))
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == 1) {
                    cur?.let { n ->
                        val dup = items.indexOfFirst {
                            abs(it.x1 - n.x1) < 1 && abs(it.y1 - n.y1) < 1 &&
                                abs(it.x2 - n.x2) < 1 && abs(it.y2 - n.y2) < 1
                        }
                        if (dup >= 0) items.removeAt(dup) else items.add(n)
                    }
                    cur = null
                } else {
                    tmp?.let { r ->
                        if (r.width() > 200 && r.height() > 200) { board = r; onBoardSet?.invoke(r) }
                    }
                    tmp = null
                }
            }
            MotionEvent.ACTION_CANCEL -> { cur = null; tmp = null }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        for (a in items) drawItem(c, a)
        cur?.let { drawItem(c, it) }
        if (mode == 2) (tmp ?: board)?.let { c.drawRect(it, frame) }
    }

    private fun drawItem(c: Canvas, a: A) {
        val s = sq()
        if (hypot(a.x2 - a.x1, a.y2 - a.y1) < s * 0.3f) { // tap = circle on the square
            line.strokeWidth = s * 0.07f
            c.drawCircle(a.x1, a.y1, s * 0.46f, line)
            return
        }
        val ang = atan2(a.y2 - a.y1, a.x2 - a.x1)
        val ca = cos(ang)
        val sa = sin(ang)
        val head = s * 0.45f
        val bx = a.x2 - ca * head
        val by = a.y2 - sa * head
        line.strokeWidth = s * 0.17f
        c.drawLine(a.x1, a.y1, bx, by, line)
        val p = Path()
        p.moveTo(a.x2, a.y2)
        p.lineTo(bx - sa * head * 0.55f, by + ca * head * 0.55f)
        p.lineTo(bx + sa * head * 0.55f, by - ca * head * 0.55f)
        p.close()
        c.drawPath(p, fill)
    }
}
